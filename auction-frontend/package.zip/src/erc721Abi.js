const erc721Abi = ["function approve(address to, uint256 tokenId) external"];
export default erc721Abi;
